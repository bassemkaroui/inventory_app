from .divers import create_divers_router
from .inventory import create_inventory_router
from .item import create_item_router